Banglalink RSO-06 — v117 APK Build Package

এটি Android project source ZIP; এটি নিজে APK নয়।
এই প্যাকেজে repository root-এর .github/workflows/android-apk.yml workflow আছে, যাতে GitHub-এ source upload করার পর Android debug APK build করা যায়।

APK তৈরির সংক্ষিপ্ত ধাপ (Android ফোন থেকেও GitHub ওয়েবসাইটে করা যায়):
1. GitHub-এ sign in করে New repository তৈরি করুন। Public নয়, Private রাখাই ভালো।
2. ZIP extract করুন। এর ভেতরের .github ফোল্ডার এবং v76 ফোল্ডার—দুটিই repository-র root-এ upload করুন। GitHub-এ .github/workflows/android-apk.yml পথটি ঠিকমতো থাকতে হবে।
3. GitHub repository-তে Actions tab খুলুন। “Build Banglalink RSO-06 APK” workflow নির্বাচন করুন।
4. “Run workflow” চাপুন। প্রথমবার Actions enable করার অনুমতি চাইলে enable করুন।
5. Build সফল হলে ওই run-এর পৃষ্ঠায় নিচে Artifacts অংশে “Banglalink-RSO-06-v117-debug-apk” ডাউনলোড করুন। ZIP artifact খুললে app-debug.apk পাবেন।
6. APK ইনস্টল করার আগে আগের অ্যাপের backup রাখুন। Package name একই হলেও signing key ভিন্ন হলে পুরোনো অ্যাপের উপর update নাও হতে পারে; তখন পুরোনো অ্যাপ uninstall করবেন না—আগে জানান।

সতর্কতা:
- Workflow তৈরি করা হয়েছে, কিন্তু GitHub-এ চালিয়ে APK build হয়েছে—এমন দাবি করা হচ্ছে না।
- Debug APK পরীক্ষার জন্য; এটি Play Store release APK নয়।
- App data সাধারণত ফোনের app storage-এ থাকে। নতুন build install/update করার আগে backup নিন।
- এই project-এর JavaScript syntax ও ZIP integrity যাচাই করা হয়েছিল; পূর্ণ Android build এবং ফোনে কার্যকরী পরীক্ষা এখনো হয়নি।
